# SI8 Creator Record — Round 2 Export Package

Prepared for engineering feasibility review. Design direction is settled; the objective now is engineering reproducibility, not another creative round.

## Status key — read first

Everything in this package falls into one of three buckets. **Do not treat anything as approved beyond the first bucket.**

### ✅ Approved design direction (build against this)
The Institutional Trust visual system and its execution: the three registers (declaration / guidance / reading), guidance-first hierarchy, the repeatable components, the reconciled brand foundation, the token set, and the pagination/accessibility rules. These are the agreed design.

### 🟡 Proposed content & structure changes (NOT approved — product/governance sign-off required)
Everything in the **Proposed-Change Register**: optional shortened labels, information-structure changes, display wording treatments, and upstream-data/product-semantics proposals. **No proposed wording or upstream-data change is approved through this design exercise.** Each needs explicit sign-off before implementation. The customer-facing mockups preserve approved production wording; the proposals are documented separately so none is adopted silently.

### 🔴 Unresolved governance decisions (resolve before/with engineering)
1. **Disclaimer presentation.** The quieter recurring footer is approved *in principle only*. Whether the production all-caps banner presentation is a **governed** requirement must be verified (engineering/legal). If governed, retain the heavier presentation. The disclaimer repeats on every page regardless, so any separately shared page states on its face that it is self-declared, not a clearance, and not a human-reviewed assessment.
2. **Applicability-dependent guidance** would need a new governed data concept (conditions + linked open item).
3. **Multiple-consideration ordering** must be confirmed as "named order, never ranked."
4. **Governed layout version & fingerprint** for the implemented design (new, not the reference values shown).

## Contents

| Folder | File(s) | What it is |
| --- | --- | --- |
| `pdf/` | `SI8-Creator-Record-Complete-Reference.pdf` | The complete 7-page reference Creator Record. |
| `pdf/` | `SI8-Creator-Record-Variants-and-StressTests.pdf` | First-page states + variable-content stress tests (6 pages). |
| `pdf/` | `Main.pdf … DocFree.pdf` | Each page/variant as an individual PDF. |
| `design-system/` | `README.md`, `02–08*.md`, `design-system.json`, `tokens.json` | Implementation-oriented SI8 Document Design System. |
| `design-tokens/` | `tokens.json` | Machine-readable design tokens (copy, for convenience). |
| `source/` | `*.dc.html` | Canvas design source for every page (authoring format). |
| `source/standalone-html/` | `*.html` | Self-contained print HTML used to render the PDFs (no runtime dependency). |
| `change-register/` | `SI8-Creator-Record-Proposed-Change-Register.md` | The proposed-change register (mirrors the live commentable doc). |

## Reference-data caveat

Every production identifier, fingerprint, **page number and page count** in the PDFs/source is **reference data from one record (CR-2026-7E82CA09)**. The implemented generator must dynamically populate all of these and carry its own governed layout version and fingerprint.

## Rendering notes

- Page size: US Letter, 816 × 1056 px at 96 dpi (8.5 × 11 in). Fonts: Fraunces, Inter, IBM Plex Mono (self-host for deterministic generation).
- PDFs were rendered from the standalone HTML via headless Chromium at 2× scale; they are faithful to the canvas mockups.
- The standalone HTML is the canvas source with the editor runtime stripped — useful as a plain-HTML reference, not the production template.

## Live artifacts (editable)

- **Design canvas** (all pages + variants + stress tests) and **Design System** and **Proposed-Change Register** remain live and editable in Claude; this package is the point-in-time export for engineering. The brand "8" mark is **provisional** and unapproved pending official SI8 assets.
