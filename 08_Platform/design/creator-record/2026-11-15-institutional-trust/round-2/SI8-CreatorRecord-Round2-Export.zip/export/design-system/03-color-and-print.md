# Colour & grayscale print

All colour values live in `tokens.json`. Three palettes, each scoped to a register, plus the gold editorial accent. **Never** introduce a colour outside the tokens.

## Reconciliation with the SI8 brand foundation

These tokens carry the website brand foundation; the rest are document-specific functional extensions.

| Brand foundation | Value | Token |
| --- | --- | --- |
| Paper | `#F7F5EF` | `paper` |
| Raised paper | `#FDFCF9` | `paper-raised` |
| Ink | `#1C1C1E` | `ink` |
| Institutional blue | `#233F66` | `navy` |
| Deep blue | `#182C48` | `ink-strong` |
| Blue tint | `#E9EDF3` | `navy-tint` |

Functional extensions (not in the website foundation, retained for the document): the full clinical reading palette (`cool-*`, `slate-*`), the gold editorial accent (`gold*`), the secondary/muted warm greys, and the `ink-fine` / `slate-fine` footer tokens.

## Palettes

**Warm register (declarations, guidance, limitations, how-made)** — grounds `paper` / `paper-raised` / `paper-sunk`; text `ink` / `ink-strong` / `ink-secondary` / `ink-muted`; rules `hairline` / `hairline-card` / `hairline-soft`.

**Institutional navy** — `navy` solid (guidance index, guidance rule, brand only); `navy-line` on navy; `navy-tint` + `navy-tint-border` for the **quiet** boundary panels.

**Gold accent** — `gold` (numerals, eyebrows), `gold-line` (em-dash markers), and the caution-note trio `gold-note-bg` / `gold-note-border` / `gold-note-ink`. Gold is **editorial**, never a status colour. Because there is no red or green anywhere, the parchment gold cannot be read as a traffic light.

**Clinical register (automated document readings only)** — ground `cool-ground`; surfaces `cool-surface` / `cool-raised` / `cool-cell` / `cool-chip`; primary `slate`; text `slate-ink` / `slate-secondary` / `slate-muted` / `slate-faint`; rules `cool-hairline` / `cool-hairline-soft` / `cool-hairline-faint`.

## Grayscale printing

The document must remain correct and legible printed in black-and-white. Because the registers are distinguished by **ground tint, type family and layout** — not by hue alone — grayscale conversion preserves the distinction: the clinical register still reads as a cooler, monospace, tabular surface; the guidance index still reads as the one dark-filled block. Requirements:

- Never encode meaning in hue alone. Every meaningful distinction (register, label vs value, caution vs plain) is **also** carried by weight, family, position or a border.
- Ensure every ground/text pair keeps ≥ 4.5:1 after grayscale conversion. The token pairs below are chosen to survive it; the one at-risk pair is the footer fine print (see Accessibility).
- The solid-navy guidance block inverts to near-black in grayscale and stays the clear focal point — intended.
- Caution notes keep their **left border + background tint**, which both survive grayscale, so they do not rely on gold being visible.
