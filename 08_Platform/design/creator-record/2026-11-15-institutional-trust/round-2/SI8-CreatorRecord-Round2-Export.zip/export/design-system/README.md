# SI8 Document Design System

The visual language for SuperImmersive 8's customer-facing documents, beginning with the **Creator Record**. It exists to make an SI8 document read as careful, credible and institutional — something a creator is comfortable sharing and a commercial stakeholder trusts — while holding exactly the boundaries of what SI8 has and has not established.

This system is **implementation-oriented**. It is written to be reproduced by a deterministic, variable-length PDF generator with no manual page placement. Every value here is a token or a rule, not a one-off decision on a mockup.

> **Scope note.** This first release is derived from the Creator Record v2. The foundations (type, colour, spacing, registers, pagination, accessibility) are intended to extend to other SI8 document products later. Defining this system makes **no change** to any existing SI8 product's current design.

## Brand reconciliation

This system is reconciled with the SI8 website brand foundation for coherence across SI8 surfaces; it does **not** alter the website or any other SI8 interface. Shared foundation values: **Paper** `#F7F5EF`, **Raised paper** `#FDFCF9`, **Ink** `#1C1C1E`, **Institutional blue** `#233F66`, **Deep blue** `#182C48`, **Blue tint** `#E9EDF3`, **Fraunces** (display), **Inter** (functional). The document-specific **three-register model** and its functional palette extensions — the clinical reading register, the gold editorial accent, and **IBM Plex Mono** for identifiers and machine-read content — are retained as additions to the foundation, not replacements.

---

## The one idea: three registers, never reconciled

An SI8 document carries up to three *kinds* of information. They must never be visually merged, because merging them would overstate what SI8 established. The system gives each kind its own register:

| Register | Carries | Ground | Voice |
| --- | --- | --- | --- |
| **Declaration** (warm) | What the creator told SI8 | `paper` `#f7f5ef` | The creator's own words, recorded as given |
| **Guidance** (warm institutional) | SI8's published educational guidance | `paper` + `navy` accents | SI8's published knowledge — the core value |
| **Reading** (cool, clinical) | What an automated model reported a document appears to show | `cool-ground` `#eceff3`, monospace | A machine observation — visibly a different kind of thing |

**Hard rule.** A creator *declaration* and an automated *reading* of the same field (for example, a declared plan and a plan read from a receipt) are never placed in a shared row, table, side-by-side comparison, or any proximity that reads as "two values of one field." They live in different registers and, normally, on different pages. A reading never implies validation, reconciliation or comparison with a declaration or with guidance.

## What solid navy is for

`navy` is the institutional signal. **Reserve it for SI8's published knowledge and the core product value** — the first-page guidance index and the guidance rule. Explanatory or boundary blocks (e.g. *How this differs from a human-reviewed assessment*, *What SI8 did not do*) use the **quiet** treatment: `navy-tint` fill, `navy-tint-border`, a 3px `navy` left rule. They stay conspicuous and fully legible; they are not minimised. This keeps navy meaningful instead of decorative.

## Forbidden visual conclusions

Credibility is built from typography, hierarchy, transparency and consistency — **never** from symbols of certification. The generator must not render: scores, ratings, risk levels, traffic-light colours, pass/fail, verified/approved badges, clearance checkmarks, completeness percentages, certification seals, or signatures implying human review. "0 open items" must always read as *a count*, never as a clean bill — pair it with its standing caution.

## Reference-only identifiers (important)

Every production identifier and fingerprint shown in the current mockups — record format/builder versions, question/guidance/wording set versions, questionnaire and layout references, and all SHA-256 fingerprints, **and the page numbers and page counts** — is **reference data from one production record**. The implemented design has its **own** governed layout version and fingerprint, and all of these fields, page references and counts must be **dynamically populated** at generation time. Nothing here hard-codes them.

## The brand mark is provisional

The standalone "8" tile used on the first page is a **provisional** placeholder, not an approved SI8 logo. Official brand assets will be supplied separately and should replace it. `radius-lg` and the mark's navy tile exist only to reserve the space.

---

## How to use this system

1. **Tokens first.** `tokens.json` holds every colour, type style, spacing step and radius. Build from tokens; never pick a raw hex on the page.
2. **Read the sections** in order: Typography → Colour & print → Layout & grid → Components → Pagination & generation → Accessibility → Governance notes.
3. **Reusable components vs. fixed pages.** The *Components* section defines the reusable, data-driven building blocks (masthead, section header, consideration block, declaration field, tool card, document-reading table, qualification note, metadata grid, empty states). The page mockups on the Creator Record canvas are *compositions* of these components for one sample record — they are examples, not the source of truth. When the two disagree, the component spec wins.

Downstream agents and engineers: start here, then `tokens.json`, then the section files.
