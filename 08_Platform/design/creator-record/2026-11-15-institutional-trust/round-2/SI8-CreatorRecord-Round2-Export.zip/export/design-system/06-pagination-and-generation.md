# Pagination & automated generation

The Creator Record is a **dynamically generated, variable-length** document. This system must be reproducible by an automated generator with **no manual page placement and no per-record design intervention**. These are the rules that make the output deterministic. They are library-agnostic; the engineering team assesses renderer compatibility separately.

## Content-driven pagination

- Pages are **filled by flowing content**, not by assigning one section per page. A section begins where the previous one ends and continues onto the next page when it overflows.
- A new page is forced only for the **register change** into automated document readings (clinical ground) and back — because the whole-page ground is itself a boundary signal — and wherever a component's keep-together rule requires it.
- Page count `M` and every `Page N of M` are computed after layout and **dynamically populated**. Never hard-code a page count. (The 7-page sample edition is one record's result, not a target.)

## Keep-together & break rules

- **Masthead and footer** repeat on every page (register-correct). The standing disclaimer is never dropped.
- **Section header**: never the last element on a page (no orphaned heading); keep with at least its first block.
- **Consideration block**: keep the header with *Why selected* and the first two lines of the guidance sentence together. If the block overflows, break **after** a labelled sub-part, repeat the provider/subject as a "(continued)" header on the next page, and keep *Please note* and *Open items* with the guidance they qualify — never separate a consideration's conditions onto a page that doesn't also carry the guidance they belong to.
- **Document reading**: a document may span pages. Break between labelled groups; repeat the document identity as a "(continued)" header; keep each observation's *value + basis + read-from* together (never split a value from its basis). Reading limitations and provenance may continue to a following page with the continuation cue.
- **Declaration field**: keep a label with its value; a long multi-line value may break internally but not away from its label.
- **Orphans/widows**: minimum 2 lines of any paragraph on each side of a break.
- **Tables/grids**: repeat column context when a grid continues; never leave a single header row at a page foot.

## Overflow & long strings

- **Long project title / long answers**: wrap freely to as many lines as needed; never truncate or ellipsize creator content.
- **Long technical strings** (SHA-256, references, filenames): `mono-fine`, `word-break: break-all`, `line-height: 1.55`, inside their cell. They never force horizontal overflow.
- No element relies on fitting a fixed height; over-tall content paginates rather than clipping.

## Zero- and missing-content states

Every repeatable region has an explicit empty state, and an empty state is **never** silence:
- **No considerations** → first-page guidance index becomes the quiet empty state; section 2 states no guidance was selected; value framed as the organised declarations.
- **No documents** → section 6 renders the document-free empty panel; absence framed as "not a finding."
- **An unsupported provider** (named tool with no guidance) → listed in the dashed "no published guidance" panel with the fixed "not a finding" sentence.
- **Insufficient / unrelated document** → the reading reports what it could not establish; the declaration is preserved unchanged.
- "0 open items" / "0 considerations" always render with the standing caution.

## Internationalisation

- Lay out for variable text length (declarations may be in any language/script). Grids use `minmax(0, 1fr)` so cells shrink rather than overflow.
- Ship font coverage for the scripts SI8 supports, or a correctly-shaping fallback, so declarations in non-Latin scripts render. Fraunces/Inter/IBM Plex Mono cover Latin; add a CJK and other-script fallback family in the stack for creator content.
- Never uppercase-transform creator content (some scripts have no case; uppercasing can corrupt meaning). Eyebrows are English UI labels only.
- Dates and identifiers are shown as produced by the system; do not locale-reformat fingerprints or references.
