# Layout & grid

## Page

- **US Letter**, 816 × 1056 px at 96 dpi (8.5 × 11 in). An A4 variant uses the same margins and scale; the grid is defined in px and reflows.
- Margins: `margin-x` 56px left/right, `margin-top` 56px, `margin-bottom` 40px. Content column ≈ 704px.
- Single-column measure. Multi-column grids are used only inside components (metadata grids, two-up qualification/open-items), never for the page body.
- Vertical rhythm uses the `space-*` scale. Default gap between major sections is `space-6` (24px); between blocks `space-4` (16px).

## Running header (every page)

- A hairline-ruled masthead: left = `SI8 Creator Record` (eyebrow, `navy` on warm pages / `slate` on clinical pages); right = the record number (`mono-id`).
- The **first page** replaces the left text with the brand lockup (provisional mark + `SuperImmersive 8` / `Creator Record`) and adds the issue date at right.
- The masthead rule is 1.5px `navy` (warm) or 1.5px `slate` (clinical). The clinical masthead is the signal that the page is an automated-reading page.

## Running footer (every page)

- A 1px `hairline` rule, then two items: left = the **standing disclaimer** strip (`footnote`, `ink-fine`): *Self-declared record · Document readings are automated, not checked by a person · Educational guidance · Not legal advice · Not a clearance*; right = `Page N of M` (`mono-id`, dynamically populated).
- The standing disclaimer repeats on **every** page and is never dropped to save space.

## Register grounds

The page background changes with register: warm pages use `paper`; automated-reading pages use `cool-ground` and the clinical masthead/footer rule colour. This whole-page cue is deliberate — turning a page into the reading register is itself a boundary signal.
