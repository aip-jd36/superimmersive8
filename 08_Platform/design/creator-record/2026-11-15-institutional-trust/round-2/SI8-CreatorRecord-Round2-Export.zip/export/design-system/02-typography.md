# Typography

Three families, each with a full fallback stack so a renderer without the webfont still produces a correct document.

| Role | Family token | Stack | Hosted source |
| --- | --- | --- | --- |
| Display | `display` | `"Fraunces", Georgia, "Times New Roman", serif` | Fraunces (Google Fonts) |
| Body / UI | `body` | `"Inter", system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif` | Inter (Google Fonts) |
| Mono / identifiers | `mono` | `"IBM Plex Mono", ui-monospace, "SF Mono", "Cascadia Code", Menlo, Consolas, monospace` | IBM Plex Mono (Google Fonts) |

For offline/deterministic PDF generation, **self-host** the three families (WOFF2 + the matching weights) rather than relying on Google Fonts at render time. Weights used: Fraunces 400/500/600; Inter 400/500/600; IBM Plex Mono 400/500.

## Scale (from `tokens.json` → `type.groups`)

**Display (Fraunces)** — `title-xl` 52/53 · 500 (project title) · `h2-section` 26/29 · 500 · `h3-block` 20/23 · 500 · `lead-guidance` 17/25 · 400 (the guidance sentence; the single typographic hero).

**Text (Inter)** — `eyebrow` 10.5/16 · 600 · uppercase · tracking .14em · `label` 12/17 · 500 · `body` 13/20 · 400 · `body-strong` 13/20 · 600 · `caption` 11/16 · 400 · `footnote` 9/14 · 400.

**Mono (IBM Plex Mono)** — `mono-value` 13/18 · 500 · `mono-id` 12/17 · 400 · `mono-fine` 10/16 · 400 (fingerprints, long strings).

## Rules

- **Serif is for SI8's voice and the guidance**, not for creator content. Project title, section headings, consideration/card titles and the guidance sentence are Fraunces; everything a creator declared is Inter.
- **Mono marks machine/technical content**: identifiers, dates, counts, read values, fingerprints. In the clinical register, read values are mono by default — this is part of what signals "a tool reported this."
- Eyebrows are the only uppercase text. Never set body copy or legal text uppercase.
- Minimum printed body size is **12px**; legal/standing text uses `footnote` (9px) only for the repeating disclaimer strip and must use the `ink-fine` colour (see Accessibility).
- Long technical strings (fingerprints, filenames, references) set in `mono-fine` with `word-break: break-all` and `line-height: 1.55` so they wrap inside their cell.
