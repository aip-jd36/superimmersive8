# Governance notes

Design rules that exist to protect what the document may and may not claim. These are not stylistic preferences; changing them changes the product's meaning and needs product/governance sign-off.

1. **Three kinds of information stay separate.** Creator declarations, SI8 published guidance, and automated document readings are three registers and are never visually merged. A reading is never placed to imply validation, reconciliation or comparison with a declaration or with guidance selection/qualification.

2. **The declaration/reading non-reconciliation is absolute.** The synthetic Runway *Pro* declaration and Runway *Standard* reading in the sample must remain independent — different registers, normally different pages, never a shared field, row or comparison. This generalises to any declared-vs-read value.

3. **Favourable guidance never floats free of its conditions.** Each consideration's qualifications, dependencies and open items render inside its own block. A reader must not be able to lift the favourable sentence away from its conditions.

4. **No new conclusions.** The design never ranks, prioritises, compares or scores considerations, and never generates summaries of governed guidance. Order is "as the tools were named." No overall verdict is ever synthesised.

5. **No certification signals.** No scores, ratings, risk levels, traffic lights, pass/fail, badges, clearance checkmarks, completeness percentages, seals, or signatures implying human review. "0 open items" and "0 considerations" always carry the standing caution.

6. **Limitations read as rigor, not retreat — and are never made inconspicuous.** The quiet treatment for boundary blocks is a hierarchy choice (reserve solid navy for value); it preserves full wording, size and prominence.

7. **Wording is governed.** The customer-facing document uses approved production wording. Any shortened display label, consolidation, reorder or restructure is a *proposal*, logged in the separate proposed-change register, not applied silently. Uncertainty is never removed and no commercial/evidential conclusion is ever strengthened.

8. **Identifiers are reference-only and dynamic.** Production versions, references, fingerprints, page numbers and page counts shown anywhere are reference data from one record. The implemented design carries its own governed layout version and fingerprint, and populates all such fields at generation time.

9. **The brand mark is provisional.** The "8" tile is a placeholder pending official SI8 assets; it is not an approved logo.

10. **Disclaimer prominence is unresolved.** The quieter recurring footer is approved in principle only. Whether the production all-caps banner presentation is a governed requirement must be verified by engineering/legal before implementation (see Accessibility). The disclaimer repeats on every page so any separately shared page states on its face that it is self-declared, not a clearance, and not a human-reviewed assessment.

11. **Nothing is approved through this design exercise.** No proposed wording change, display relabelling, information-structure change or upstream-data proposal — here or in the change register — is approved by virtue of appearing in these mockups. Each requires explicit product/governance sign-off.
