# Accessibility & contrast

The document must be legible in colour and in grayscale, on screen and in print.

## Contrast obligations

- Body and label text: **≥ 4.5:1** against its ground. Large text (≥ 24px, or ≥ 18.66px bold): ≥ 3:1. Borders and non-text UI that carries meaning: ≥ 3:1.
- Token pairs are chosen to meet this on their stated grounds in the Paper theme. Verify after any token change.
- **Footer standing-disclaimer (applied).** The mockups now set the disclaimer at **`ink-fine` (`#5f6670`)** on warm pages and **`slate-fine` (`#5a6672`)** on clinical pages, at 9.5px with tighter tracking. `ink-faint` is reserved for genuinely non-essential, decorative text that is not the sole carrier of meaning. **Engineering must verify comfortable legibility at the target print DPI — not merely a digital 4.5:1 ratio** — and may increase the size further; it must never truncate, wrap illegibly, or drop any approved disclaimer wording.
- **Governed-disclaimer presentation — engineering verification required (unresolved).** The production record presents the standing disclaimer as an all-caps banner at the top of each page. Whether that specific presentation (caps, size, placement, prominence) is a *governed* requirement is **unresolved**. The quieter recurring footer is approved **in principle only**, subject to this check: if the heavier presentation is governed, retain it. In all cases the disclaimer repeats on **every** page, so any separately shared page states on its face that the record is self-declared and not a clearance or human-reviewed assessment.
- Clinical `slate-faint` *Read from* text sits on `cool-surface`/white table cells — verify ≥ 4.5:1; if a smaller size is used, darken to `slate-secondary`.

## Not colour alone

Every distinction is carried by more than hue: register (ground + family + layout), label vs value (weight + position + family), caution (border + tint + text), guidance index (solid fill + position). This is what makes grayscale printing correct and serves colour-vision deficiency. Where two things must be told apart, they differ in **lightness**, not hue; the palette avoids red/green entirely.

## Document semantics

- Generate **tagged PDF** (PDF/UA): real heading levels (section headers → H2, block titles → H3), lists as lists, tables with header cells and scope, and a logical reading order that matches the visual flow.
- Set document language; set per-run language on declaration content where known so a screen reader pronounces it correctly.
- Provide a document title and the record number in metadata.
- Never convey a state through an icon alone without a text equivalent (there are no status icons in this system by design, which helps).

## Print

- Minimum printed body 12px; the 9px disclaimer is the single exception and must use `ink-fine`.
- Ensure 4.5:1 survives grayscale conversion for every text/ground pair.
