# Components

Reusable, data-driven building blocks. Each is defined by its structure, the tokens it uses, and how it behaves as its data varies. The canvas mockups are **compositions** of these for one sample record; where they differ, this spec wins.

## Chrome

**Masthead** — two variants. *Standard*: wordmark (eyebrow) left, record number (`mono-id`) right, 1.5px rule. *First-page lockup*: provisional mark + `SuperImmersive 8`/`Creator Record` left, record number + issue date right. Rule and label colour follow the register (`navy` warm / `slate` clinical).

**Footer** — standing disclaimer (`footnote`/`ink-fine`) + `Page N of M` (dynamic). Always present.

**Section header** — Fraunces numeral (`gold`) + `h2-section` title. One per numbered section.

## First-page components

**Info-type overview card** — small `paper-raised` card: `h3-block` title + `mono-fine` section ref (`§3–5`) + one-line `caption`. Rendered once per information *kind present* (declarations, guidance, readings, limitations). Drives the "what this record contains" grid. In the no-guidance state the guidance card switches to the muted/dashed empty variant.

**Guidance index** — the **core-value** component; the only solid-`navy` block on page 1. Header: eyebrow + consideration count. Body: one **index row** per consideration — provider eyebrow, `h3-block` subject, right-aligned open-item count (`mono`, neutral) + page reference. States:
- *One* consideration → single row.
- *Many* → one row per consideration, in the order tools were named, with the standing line "Listed in the order you named the tools. Not ranked, prioritised or compared." **No** ranking, prioritisation, comparison or AI summary.
- *None* → the index is replaced by the **quiet empty state** (`paper-empty`, dashed, `gold-line` rule): "No published SI8 guidance was selected," plus the value-preserving note. Not a navy value panel.

**Record summary** — inline count strip (`mono` figures + `body` labels) + the **standing caution** note (see Caution note). Counts are dynamic; the caution text is fixed and never omitted.

## Guidance (warm institutional)

**Consideration block** — the repeatable unit, provider- and topic-independent, **self-contained**. Fixed internal order: (1) header: provider eyebrow + `h3-block` subject + `Consideration N`; (2) *Why this was selected* (echoes the declaration that triggered it); (3) *What the guidance says* — the guidance sentence in `lead-guidance`, 3px `navy` left rule; (4) *Please note* — this consideration's qualifications; (5) *Open items* — this consideration's open items. **Rule:** qualifications and open items are rendered **inside** the block, so favourable guidance is never read apart from its conditions. When several blocks appear, each carries its own (4) and (5); nothing is pooled across considerations.

**Applicability-dependent variant** — a consideration whose guidance applies only under conditions adds an *Applicability depends on — not established* panel (gold caution) **above** its qualifications, and the matching open item in (5). The guidance sentence is shown **conditionally** and is never a finding that it applies.

**Does-not-establish panel** — gold caution listing the named tools/services with no guidance, plus the fixed "not a finding" sentence.

**Quiet boundary panel** — `navy-tint` fill + `navy-tint-border` + 3px `navy` left rule. Used for *How this differs from a human-reviewed assessment* and for *What SI8 did not do*. Conspicuous, fully legible, but not solid navy.

## Declarations (warm, the creator's voice)

**Register banner** — `h3-block` "What you told SI8" + rule + "Recorded as you gave it · no person checked it."

**Declaration field** — label (`label`/`ink-muted`, the **exact production question**) in a fixed-width left column, value (`body`/`ink-strong` or `ink-secondary`) right. Multi-select values render as a `·`-separated list in the value cell; long values wrap. Long titles wrap to multiple lines without truncation.

**Tool card** — modular, one per declared tool, numbered `Tool N`. Three fields (tool / plan / when) in a `paper-raised` card. Stacks vertically for many tools.

**"Not sure" tag** — small `gold-note` chip appended to a value the creator marked uncertain. Never changes the value.

## Readings (clinical)

**Automated-reading banner** — `slate` tab + note; always states readings were not compared with declarations or guidance.

**Document card** — header (document/file index, filename in `mono`, type/size/description/examination chips) + body. One per document; stacks for many; continues across pages via the continuation rule.

**Observation table** — grouped by **basis**: *the reading's own description* (compact 2-up cells) and *text printed on the document* (label column + value + the quoted *Read from* source text in `slate-faint` + optional *Where it appears* chip). Every observation carries its basis; where supplied, its location.

**Reading limitations** — em-dash list on `cool-surface`. **Provenance grid** — `mono` key/value grid (reference, method, provider, model, read-at, profile). **Fingerprint block** — `cool-raised` panel, `mono-fine` SHA-256 (break-all) + the "a fingerprint does not show a document is genuine" note.

## Shared

**Caution note** — `gold-note-bg` + 2px `gold-note-border` left + `gold-note-ink` text. The reusable carrier for every "this is not a finding / not an absence of issues" statement. Used for the record-summary caution, does-not-establish, applicability, and unsure answers.

**Metadata grid (appendix)** — dense `mono` key/value grid (2- or 4-column) on `paper`, for record-generation and provenance identifiers. All values dynamic.

**Empty state** — dashed panel (`paper-empty` warm / dashed `cool-surface` clinical) with a `h3-block`/display line + value-preserving note. Variants: no guidance, no documents.
