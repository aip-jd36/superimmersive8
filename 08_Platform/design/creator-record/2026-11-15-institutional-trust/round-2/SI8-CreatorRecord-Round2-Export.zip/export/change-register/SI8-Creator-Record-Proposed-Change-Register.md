# SI8 Creator Record — Proposed-Change Register

*As of 2026-11-15 · prepared by JD Chang*

A record of every place the Institutional Trust redesign rewrites, shortens, consolidates, relabels or restructures the production Creator Record, kept separate from the customer-facing document. Each entry gives the original production content, the proposed treatment, the design rationale, and whether it affects information hierarchy, meaning, or required upstream data. **Nothing here is applied to the customer document silently; all are proposals for product/governance review. No proposed wording or upstream-data change is approved through this design exercise.**

> This markdown mirrors the live, commentable register doc. The live doc carries one open comment on item 3's disclaimer question.

## How to read this register

The redesign preserves the approved production wording in the customer-facing document. Every item below is a proposal for product/governance review, not a change already applied.

- Each entry gives: original production content, the proposed treatment, the design rationale, and impact across three axes — information **hierarchy**, **meaning**, and required **upstream data**.
- No proposal removes uncertainty, weakens a qualification or disclaimer, or strengthens any commercial or evidential conclusion.
- No proposal introduces a score, rating, clearance indicator, badge, seal, or any suggestion of human review.
- "Affects meaning: No" means the governed meaning is unchanged — the change is display or structure only.

## 1. Shortened display labels → original questions

An **optional** short-label set for a denser layout. The current edition keeps the full production questions; these would be used only if a denser presentation is later required, and only with the original question retained as the governed text (e.g. on expand). **Recommendation: keep the full questions in the customer PDF, as the current edition does.** Affects meaning: No (provided the original governed question is retained). Affects upstream data: No.

| Original production question | Proposed short display label |
| --- | --- |
| What is the title of the video? | Title |
| Describe the video in a sentence or two (optional). | Description |
| How do you intend to use the video? Select all that apply. | Intended use |
| Where are you or your business based? | Your base |
| Where do you expect the video to be published or shown? Select all that apply. | Shown in |
| Where is the client or advertiser based? | Client base |
| Which AI tool did you use? | AI tool |
| Which plan were you on with this tool while you made the video? | Plan |
| When did you use this tool for the video? | When used |
| Does the video include the likeness or voice of a real person? | Real-person likeness or voice |
| Does the video include any of these? Select all that apply. | Other material included |
| Where did the music come from? | Music source |
| Do you hold a licence or download receipt for the music? | Music licence or receipt |
| What did you contribute to the video yourself? Select all that apply. | Your contribution |

## 2. Information-structure changes

### a. First page: guidance index in place of a full-guidance hero
**Original** — the first page leads with record counts; full guidance text sits in section 2. **Proposed** — the first page presents a "what this record contains" overview and a guidance *index* (provider + consideration subject + page reference); the full guidance text stays in section 2. **Rationale** — scales to zero, one or many considerations; removes first-page/section-2 duplication; communicates value in seconds. **Impact** — Hierarchy: Yes (first-page emphasis). Meaning: No (no guidance text altered; the index is navigational). Upstream: minor — needs a structured list of considerations with subject and target page, already available.

### b. Content-driven pagination, dynamic page count
**Original** — production layout version 5 (six-page sample). **Proposed** — content flows; sections do not each force a new page, except the register change into automated readings; page count is computed and dynamically populated (seven-page sample). **Rationale** — removes large unused space; natural pagination. **Impact** — Hierarchy: No. Meaning: No. Upstream: No (the implemented design carries its own governed layout version).

### c. Section 9 consolidation
**Original** — acknowledgements, record-generation details and the technical appendix across separate sparse pages. **Proposed** — consolidated onto one appendix-style page. **Rationale** — fills otherwise-sparse pages; keeps provenance together. **Impact** — Hierarchy: No. Meaning: No. Upstream: No.

### d. Visual hierarchy: solid navy reserved for value
**Original** — the first-round mock used solid navy for the guidance value *and* for the "how this differs" and "what SI8 did not do" blocks. **Proposed** — solid navy only for SI8 published knowledge and core value; boundary blocks use a quiet tinted, bordered treatment. **Rationale** — keeps navy meaningful; limitations stay conspicuous and fully worded. **Impact** — Hierarchy: Yes (emphasis). Meaning: No (wording, size and prominence preserved). Upstream: No.

### e. "0 open items" caution surfaced with every count
**Original** — production states the caution within section 2. **Proposed** — the caution ("not a problem SI8 has found; not an absence of commercial issues") is placed next to every count of open items or considerations, including the first page. **Rationale** — prevents "0" reading as a clean bill. **Impact** — Hierarchy: No. Meaning: No (reinforces existing wording). Upstream: No.

## 3. Display wording treatments

Places where the design re-labels or re-groups standing wording for display only. The governed phrasing is retained verbatim in every case; meaning is not affected.

- **Per-consideration qualifications.** The "Please note" items are shown as bullets *inside* each consideration block rather than pooled in one list. Text verbatim. This strengthens the governance requirement that each consideration's conditions stay bound to its own guidance. Meaning: No. Upstream: No.
- **"Why this was selected."** The production "Selected because you told us" plus the echoed question is displayed under a "Why this was selected" label with the question echoed inline. Governed phrasing retained. Meaning: No.
- **Standing disclaimer as a footer strip.** The disclaimer ("Self-declared record · Document readings are automated, not checked by a person · Educational guidance · Not legal advice · Not a clearance") repeats on every page as a quiet, letter-spaced uppercase footer rather than a heavy banner. Wording is verbatim and case is preserved. **Flag for review (UNRESOLVED):** confirm the quieter footer placement satisfies the disclosure's intended prominence; if the heavier banner is itself governed, retain it. Meaning: No (wording unchanged); prominence treatment changed.
- **Section headers.** Numerals added; header phrasing retained (e.g. "What SI8's published guidance says"). Meaning: No.

## 4. Upstream-data & product-semantics proposals

Changes that need engineering or governed-data work. Each affects upstream data; none changes what SI8 concludes.

- **Guidance-index data.** Per consideration: provider, subject, open-item count, and target page (dynamic). Upstream: Yes (structured, largely available already). Meaning: No.
- **Applicability-dependent considerations.** A governed concept: guidance that applies only under stated conditions, carrying a structured "depends on / not established" field and a linked open item (used by the unresolved-applicability pattern). Upstream: Yes — governed guidance must carry applicability conditions. Meaning: adds a condition that **strengthens caution**, never a conclusion.
- **Multiple-consideration ordering.** A defined, non-ranking order — proposed: the order the tools were named. Governance must confirm "named order" is acceptable and never reordered by relevance. Upstream: Yes. Meaning: No (no ranking introduced).
- **Dynamic identifiers.** All production versions, references, fingerprints, page numbers and page counts dynamically populated; the implemented design gets its own governed layout version and fingerprint. Upstream: Yes. Meaning: No.
- **Internationalisation.** Font coverage and language tagging for non-Latin declarations. Upstream: Yes. Meaning: No.
- **Accessibility (applied in mockups).** Footer disclaimer now uses the darker `ink-fine` / `slate-fine` tokens at 9.5px; engineering must verify comfortable legibility at target print DPI (not merely digital 4.5:1) and output tagged PDF (PDF/UA). Meaning: No.

## 5. Explicitly preserved — no change

- All disclaimers, qualifications, "not a finding" and "does not establish" statements, the limitations of section 7, "what SI8 did not do" in section 8, and the acknowledgements in section 9 are kept **verbatim**.
- No uncertainty is removed and no commercial or evidential conclusion is strengthened anywhere.
- The creator-declaration vs automated-reading **non-reconciliation** is maintained: the declared Runway "Pro" and the read Runway "Standard" stay independent, in different registers, and are never compared or reconciled.
- No scores, ratings, clearance indicators, verification badges, certification seals, or any suggestion of human review are introduced.
